package br.com.eduardomelle.mainconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainConsumerApplication.class, args);
	}

}
