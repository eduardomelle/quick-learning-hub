package br.com.eduardomelle.mainconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
